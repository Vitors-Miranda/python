from lib import *

print(" ----------------------------")
print("|                            |")
print("|    Lanchonete delicinha    |")
print("|                            |")
print(" ----------------------------")

while True:
    menu()
