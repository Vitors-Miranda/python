# lanches > bebidas > sobremesas > entrega

headers = ["Lanches", "Bebidas", "Sobremesas", "Tipo de Entrega", "Sair"]
options = ["Sandubão do bão", "Méqui Delícia"], ["Coka Koala", "Dolly"], ["Bolinho do Bom", "Torta Gostosa"], ["Delivery", "Retirada"],
valores = [[], [], [], []]


def menu():
    cont = 1
    print("\n--- Menu de produtos ---")
    for header in headers:
        print(f"{cont}. {header}")
        cont += 1
    escolha = input("Escolha a opção desejada: ")
    print("\n")
    options(escolha)

def options(escolha):
    for value in 
    if escolha == "1":
        print("\n--- Lanches ---")
        print("1. Sandubão do bão")
        print("2. Méqui Delícia")
        print("3. Voltar ao menu")
        
    elif escolha == "2":
        print("\n--- Bebidas ---")
        print("1. Coka Koala")
        print("2. Dolly")
        print("3. Voltar ao menu")
    
    elif escolha == "3":
        print("\n--- Sobremesas ---")
        print("1. Bolinho do bom")
        print("2. Torta gostosa")
        print("3. Voltar ao menu")
    elif escolha == "4":
        print("\n--- Retirada ---")
        print("1. Delivery")
        print("2. Retirada")
        print("3. Voltar ao menu")
    
    elif escolha == "5":
        print(valores)
        print("Volte sempre!")
        exit()
    else:
        print("Opção Inválida \n")

    produto = input("Digite a opção: ")
    if(produto in [1,2]):
        valores[int(escolha) -1].append(produto)
 
